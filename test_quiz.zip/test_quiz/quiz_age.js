
const data1 = [
    {
        question:"The present age of Aradhana and Aadrika is in the ratio 3:4. 5 years back, the ratio of their ages was 2:3. What is the present age of Aradhana?"
        ,
        a:"12 years",
        b:"15 years",
        c:"5 years",
        d:"14 years",
        correct:"b",
    
    },
    {
        question:"If the total ages of Iqbal and Shikhar is 12 years more than the total age of Shikhar and Charu. Charu is how many years younger than Iqbal?"
        ,
        a:"11 years",
        b:"2 years",
        c:" 13 years",
        d:"none of the above",
        correct:"d",

    },
    {
        question:"A father is twice as old as his daughter. If 20 years ago, the age of the father was 10 times the age of the daughter, what is the present age of the father?"
        ,
        a:"40 years",
        b:"32 years",
        c:"43 years",
        d:"45 years",
        correct:"d",

    },
    {
        question:"Arun is 2 years older than Bharat who is twice as old as Charat. If the total of the ages of Arun, Bharat and Charat be 27, then how old is Bharat?"
        ,
        a:"10 years",
        b:"11 years",
        c:"12 years",
        d:"13 years",
        correct:"a",

    },

    {
        question:"The sum of the ages of a daughter and mother is 56 years; after four years the age of the mother will be three times that of the daughter. What is the age of the daughter and the mother, respectively? ?"
     
        ,
        a:"12 years,41 years",
        b:"11 years,34 years",
        c:"13 years,4 years",
        d:"12 years,44 years",
        correct:"d",

    },
    {
        question:"The average age of 8 men increases by 2 years when two women are included in place of two men of ages 20 and 24 years. Find the average age of the women?"
        
        ,
        a:"33 year",
        b:"30 year",
        c:"23 year",
        d:"19 year",
        correct:"b",

    },
    {
        question:"The average age of husband, wife and their child 3 years ago was 27 years and that of wife and the child 5 years ago was 20 years. The present age of the husband is:?"
        
        ,
        a:" 41 years",
        b:" 40 years",
        c:" 23 years",
        d:" 32 years",
        correct:"b",

    },
    {
        question:"A is 2 years older than B who is twice as old as C. If the total of the ages of A, B and C be 27, then how old is B?"
        ,
        a:"7 years",
        b:"8 years",
        c:"9 years",
        d:"10 years",
        correct:"a",

    },
    {
        question:"A person's present age is two-fifth of the age of his mother. After 8 years, he will be one-half of the age of his mother. How old id the mother at present??"
        ,
        a:"32 years",
        b:"33 years",
        c:"40 years",
        d:"47 years",
        correct:"c",

    },
    {
        question:"Three 6 faced dice are thrown together. The probability that all the three show the same number on them is A father said to his son, 'I was as old as you are at present at the time of your birth.' If the father's age is 38 years now, the son's age five years back was::?"
        ,
        a:"14 years",
        b:"13 years",
        c:"16 years",
        d:"18 years",
        correct:"a",

    },

] 

const quiz = document.getElementById("quiz")
const answerEls = document.querySelectorAll(".answer")
const questionEl =document.getElementById("question")
const optionA =document.getElementById("optionA")
const optionB =document.getElementById("optionB")
const optionC =document.getElementById("optionC")
const optionD =document.getElementById("optionD")
const submitBtn =document.getElementById("submit")
let currentQuiz = 0
let score = 0
let wronganswer=0
let total=10
let percentage

loadQuiz()

function loadQuiz(){
deselectAnswers()
const currentQuizData = data1[currentQuiz]

questionEl.innerText = currentQuizData.question
optionA.innerText= currentQuizData.a
optionB.innerText = currentQuizData.b
optionC.innerText = currentQuizData.c
optionD.innerText= currentQuizData.d

}
function deselectAnswers(){
    answerEls.forEach((answerEL)=>(
        answerEL.checked= false
    ))
}
function getSelect(){
    let answer
    answerEls.forEach((answerEL)=>{
        if(answerEL.checked){
            answer=answerEL.id
        }
    })
    return answer
}
submitBtn.addEventListener("click",() =>{
    const answer =getSelect()

if(answer){
    if(answer== data1[currentQuiz].correct){
        score++
        wronganswer=total-score; 
        percentage=score*100/total
    }
    currentQuiz++
    if(currentQuiz < data1.length){
        loadQuiz()
    }
    else
     quiz.innerHTML =`
     <h2>your score is${score}</h2>
     
     <h2>Total question=10</h2>
     <h2>currect answer: ${score}</h2>
     <h2>wrong answer: ${wronganswer}</h2>
     <h2>wrong answer: ${percentage} %</h2>
     <h2>you answered: ${score}/${data1.length} Questions correctly</h2>
     <button onclick= "location.reload()">Do it Again</button>
     

    `
}
   

})


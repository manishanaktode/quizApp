
const data1 = [
    {
        question:"In a cycle race there are 5 persons named as J,K,L,M,N participated for 5 positions. How many number of ways can M finishes always before NAn article is bought for Rs. 675 and sold for Rs. 900. Find the gain percent?"
        ,
        a:"30 2/3",
        b:"32 1/2",
        c:"33 1/3",
        d:"34 1/3",
        correct:"c",
    
    },
    {
        question:"A person buys a horse for 15 pounds. After one year, he sells it for 20 pounds. After one year, again he buys the same horse at 30 pounds and sells it for 40 pounds. What is the overall profit percent for that person over both the transactions?"
        ,
        a:"31.03%",
        b:"33.33%",
        c:"32.33%",
        d:"35.33%",
        correct:"b",

    },
    {
        question:"A trader sells 85 m of cloth for Rs. 8,925 at the profit of Rs. 15/m of cloth. What is the cost price of 1 m of cloth?"
        ,
        a:" Rs. 84",
        b:" Rs. 90",
        c:" Rs. 74",
        d:" Rs. 54",
        correct:"b",

    },
    {
        question:"A, B and C enter into a partnership. A invests some money at the beginning, B invests double the amount after 6 months, and C invests thrice the amount after 8 months. If the annual gain be Rs. 18,000. A's share is?"
        ,
        a:"Rs. 5,000",
        b:"Rs. 6,000",
        c:"Rs. 4,000",
        d:"Rs. 2,000",
        correct:"b",

    },

    {
        question:"By selling an article at Rs. 800, a shopkeeper makes a profit of 25%. At what price should he sell the article so as to make a loss of 25%?"     
        ,
        a:"Rs. 460",
        b:"Rs. 420",
        c:"Rs. 480",
        d:"Rs. 410",
        correct:"c",

    },
    {
        question:"Amit bought 160 shirts at the rate of Rs. 225/shirt. The transport expenditure was Rs. 1,400. He paid an octroi at the rate of Rs. 1.75/shirt and labour charges were Rs. 320. What should be the selling price of 1 shirt, if he wants a profit of 20%?"
        
        ,
        a:" Rs. 260",
        b:" Rs. 250",
        c:" Rs. 200",
        d:" Rs. 285",
        correct:"d",

    },
    {
        question:"A man sold two houses for Rs. 7.8 lakhs each. On the one, he gained 5% and on the other, he lost 5%. What percent is the effect of the sale on the whole?"
        
        ,
        a:"0.25 % loss",
        b:"0.25 % gain",
        c:"25 % gain",
        d:"25 % loss",
        correct:"a",

    },
    {
        question:"Profit after selling a commodity for Rs. 425 is same as loss after selling it for Rs.355. The cost of the commodity is:"
        ,
        a:"Rs. 290",
        b:"Rs. 390",
        c:"Rs. 340",
        d:"Rs. 190",
        correct:"b",

    },
    {
        question:"If two mixers and one T.V cost Rs. 7000. While two T.V s and one mixer cost Rs. 9800. The value of one T.V is:"
        ,
        a:"Rs.2,200",
        b:"Rs.4,200",
        c:"Rs.3,200",
        d:"Rs.5,200",
        correct:"b",

    },
    {
        question:"Bhajan Singh purchased 120 reams of paper at Rs. 80 per ream. He spent Rs. 280 on transportation. Paid octrai at the rate of 40 paise per ream and paid Rs. 72 to the coolie. If he wants to have a gain of 8 %. What must be the selling price per ream?"
        ,
        a:"90 rs",
        b:"60 rs",
        c:"30 rs",
        d:"100 rs",
        correct:"a",

    },

] 

const quiz = document.getElementById("quiz")
const answerEls = document.querySelectorAll(".answer")
const questionEl =document.getElementById("question")
const optionA =document.getElementById("optionA")
const optionB =document.getElementById("optionB")
const optionC =document.getElementById("optionC")
const optionD =document.getElementById("optionD")
const submitBtn =document.getElementById("submit")
let currentQuiz = 0
let score = 0
let wronganswer=0
let total=10
let percentage


loadQuiz()

function loadQuiz(){
deselectAnswers()
const currentQuizData = data1[currentQuiz]

questionEl.innerText = currentQuizData.question
optionA.innerText= currentQuizData.a
optionB.innerText = currentQuizData.b
optionC.innerText = currentQuizData.c
optionD.innerText= currentQuizData.d

}
function deselectAnswers(){
    answerEls.forEach((answerEL)=>(
        answerEL.checked= false
    ))
}
function getSelect(){
    let answer
    answerEls.forEach((answerEL)=>{
        if(answerEL.checked){
            answer=answerEL.id
        }
    })
    return answer
}
submitBtn.addEventListener("click",() =>{
    const answer =getSelect()

if(answer){
    if(answer== data1[currentQuiz].correct){
        score++
        wronganswer=total-score; 
        percentage=score*100/total
    }
    currentQuiz++
    if(currentQuiz < data1.length){
        loadQuiz()
    }
    else
     quiz.innerHTML =`
     <h2>your score is${score}</h2>
     
     <h2>Total question=10</h2>
     <h2>currect answer: ${score}</h2>
     <h2>wrong answer: ${wronganswer}</h2>
     <h2>wrong answer: ${percentage} %</h2>
     <h2>you answered: ${score}/${data1.length} Questions correctly</h2>
     <button onclick= "location.reload()">Do it Again</button>

    

     

    `
}
   

})



const data1 = [
    {
        question: "In a cycle race there are 5 persons named as J,K,L,M,N participated for 5 positions. How many number of ways can M finishes always before N?"
        ,
        a:"20",
        b:"36",
        c:"55",
        d:"60",
        correct:"d",
    
    },
    {
        question:"A box contains 3 blue marbles, 4 red, 6 green marbles and 2 yellow marbles. If three marbles are picked at random, what is the probability that they are all blue??"
        ,
        a:"1/455",
        b:"2/455",
        c:" 4/455",
        d:"1/91",
        correct:"a",

    },
    {
        question:". A Bag contains 6 Blue Balls and 4 Red Balls. 4 balls are picked at random. What is the probability that 2 are Blue and 2 are Red?"
        ,
        a:"1/5",
        b:"1/7",
        c:"3/7",
        d:"3/8",
        correct:"b",

    },
    {
        question:"A Bag contains 6 Blue Balls and 4 Red Balls. 3 balls are picked at random. What is the probability that 3 are Blue or 3 are Red?"
        ,
        a:"1/5",
        b:"1/6",
        c:"1/7",
        d:"1/8",
        correct:"a",

    },

    {
        question:" A Bag contains 6 Blue Balls and 4 Red Balls. 5 balls are picked at random. What is the probability that 3 are Blue and 2 are Red or 2 are Blue and 3 are Red? ?"
     
        ,
        a:"3/7",
        b:"4/7",
        c:"5/7",
        d:"6/7",
        correct:"c",

    },
    {
        question:" A Bag contains 6 Blue Balls and 4 Red Balls. 3 balls are picked at random. What is the prob. that none of them is Red? ?"
        
        ,
        a:"1/3",
        b:"1/5",
        c:"1/6",
        d:"1/7",
        correct:"c",

    },
    {
        question:"The probability that A speaks truth is 3/5 and that of B speaking truth is 4/7. What is the probability that they agree in stating the same fact??"
        
        ,
        a:"12/35",
        b:"15/35",
        c:"18/35",
        d:"21/35",
        correct:"c",

    },
    {
        question:" A box contains 3 blue marbles, 4 red, 6 green marbles and 2 yellow marbles. If four marbles are picked at random, what is the probability that none is blue??"
        ,
        a:"33/91",
        b:"34/98",
        c:"17/67",
        d:"3/65",
        correct:"a",

    },
    {
        question:"If a card is drawn from a well shuffled pack of cards, the probability of drawing a spade or a king is:?"
        ,
        a:" 19/52",
        b:"4/13",
        c:" 17/52",
        d:" 5/13",
        correct:"b",

    },
    {
        question:"Three 6 faced dice are thrown together. The probability that all the three show the same number on them is:?"
        ,
        a:" 1/64",
        b:" 1/36",
        c:" 1/14",
        d:" 1/44",
        correct:"b",

    },

] 

const quiz = document.getElementById("quiz")
const answerEls = document.querySelectorAll(".answer")
const questionEl =document.getElementById("question")
const optionA =document.getElementById("optionA")
const optionB =document.getElementById("optionB")
const optionC =document.getElementById("optionC")
const optionD =document.getElementById("optionD")
const submitBtn =document.getElementById("submit")
let currentQuiz = 0
let score = 0
let wronganswer=0
let total=10
let percentage

loadQuiz()

function loadQuiz(){
deselectAnswers()
const currentQuizData = data1[currentQuiz]

questionEl.innerText = currentQuizData.question
optionA.innerText= currentQuizData.a
optionB.innerText = currentQuizData.b
optionC.innerText = currentQuizData.c
optionD.innerText= currentQuizData.d

}
function deselectAnswers(){
    answerEls.forEach((answerEL)=>(
        answerEL.checked= false
    ))
}
function getSelect(){
    let answer
    answerEls.forEach((answerEL)=>{
        if(answerEL.checked){
            answer=answerEL.id
        }
    })
    return answer
}
submitBtn.addEventListener("click",() =>{
    const answer =getSelect()

if(answer){
    if(answer== data1[currentQuiz].correct){
        score++
        wronganswer=total-score; 
        percentage=score*100/total
    }
    currentQuiz++
    if(currentQuiz < data1.length){
        loadQuiz()
    }
    else
     quiz.innerHTML =`
     <h2>your score is${score}</h2>
     
     
     
     <h2>Total question=10</h2>
     <h2>currect answer: ${score}</h2>
     <h2>wrong answer: ${wronganswer}</h2>
     <h2>wrong answer: ${percentage} %</h2>
     <h2>you answered: ${score}/${data1.length} Questions correctly</h2>
     <button onclick= "location.reload()">Do it Again</button>
    

    `
}
   

})


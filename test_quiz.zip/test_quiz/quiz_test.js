
const data1 = [
    {
        question: "There are two pipes which are functioning simultaneouly to fill a tank in 12 hours, if one pipe fills the tank 10 hours faster than other then how many hours second pipe will take to fill the tank ?"
        ,
        a:"30 hours",
        b:"35 hours",
        c:"40 hours",
        d:"45 hours",
        correct:"a",
    
    },
    {
        question:"A cistern can be filled in 9 hours but due to a leak at its bottom it takes 10 hours. If the cistern is full, then the time that the leak will take to make it empty will be ?"
        ,
        a:"20 hours",
        b:"19 hours",
        c:"80 hours",
        d:"90 hours",
        correct:"c",

    },
    {
        question:"One pipe can fill a tank three times as fast as another pipe. If together the two pipes can fill the tank in 36 minutes, then the slower pipe alone will be able to fill the tank in"
        ,
        a:"144 mins",
        b:"123 mins",
        c:"111 mins",
        d:"145 mins",
        correct:"b",

    },
    {
        question:"12 buckets of water fill a tank when the capacity of each tank is 13.5 litres. How many buckets will be needed to fill the same tank, if the capacity of each bucket is 9 litres?"
        ,
        a:" 15 buckets",
        b:"16 buckets",
        c:"17 buckets",
        d:"18 buckets",
        correct:"d",

    },

    {
        question:"A tap can fill a tank in 6 hours. After half the tank is filled then 3 more similar taps are opened. What will be total time taken to fill the tank completely?"
     
        ,
        a:"2 hours 20 mins",
        b:"2 hours 3 mins",
        c:"3 hours 40 mins",
        d:"3 hours 20 mins",
        correct:"a",

    },
    {
        question:"Pipe A can fill a tank in 5 hours, pipe B in 10 hours and pipe C in 30 hours. If all the pipes are open, in how many hours will the tank be filled ?"
        
        ,
        a:"5 hours",
        b:"2 hours",
        c:"2.5 hours",
        d:"1 hours",
        correct:"c",

    },
    {
        question:"Two pipes A and B can fill a tank in 6 hours and 4 hours respectively. If they are opened on alternate hours and if pipe A is opened first, in how many hours, the tank shall be full ?"
        
        ,
        a:"15 buckets",
        b:"16 buckets",
        c:"17 buckets",
        d:"18 buckets",
        correct:"d",

    },
    {
        question:"It takes two pipes A and B, running together, to fill a tank in 6 minutes. It takes A 5 minutes less than B to fill the tank, then what will be the time taken by B alone to fill the tank?"
        ,
        a:"15 buckets",
        b:"16 buckets",
        c:"17 buckets",
        d:"18 buckets",
        correct:"d",

    },
    {
        question:"If two pipes can fill a tank in 24 and 20 minutes respectively and another pipe can empty 3 gallons of water per minute from that tank. When all the three pipes are working together, it takes 15 minutes to fill the tank. What is the capacity of the tank?"
        ,
        a:"100 gallons",
        b:"120 gallons",
        c:"130 gallons",
        d:"140 gallons",
        correct:"b",

    },
    {
        question:" Pipe A can fill the tank 3 times faster in comparison to pipe B. It takes 36 minutes for pipe A and B to fill the tank together. How much time will pipe B alone take to fill the tank?"
        ,
        a:"100 minutes",
        b:"134 minutes",
        c:"124 minutes",
        d:"144 minutes",
        correct:"d",

    },

] 


const quiz = document.getElementById("quiz")
const answerEls = document.querySelectorAll(".answer")
const questionEl =document.getElementById("question")
const optionA =document.getElementById("optionA")
const optionB =document.getElementById("optionB")
const optionC =document.getElementById("optionC")
const optionD =document.getElementById("optionD")
const submitBtn =document.getElementById("submit")
const userName=document.getElementById("user_name")

let currentQuiz = 0
let score = 0
let wronganswer=0
let total=10
let percentage

loadQuiz()

function loadQuiz(){
deselectAnswers()
const currentQuizData = data1[currentQuiz]

questionEl.innerText = currentQuizData.question
optionA.innerText= currentQuizData.a
optionB.innerText = currentQuizData.b
optionC.innerText = currentQuizData.c
optionD.innerText= currentQuizData.d

}
function deselectAnswers(){
    answerEls.forEach((answerEL)=>(
        answerEL.checked= false
    ))
}
function getSelect(){
    let answer
   
    answerEls.forEach((answerEL)=>{
        if(answerEL.checked){
            answer=answerEL.id
        }
    })
    return answer
}
submitBtn.addEventListener("click",() =>{
    const answer =getSelect()

if(answer){
    if(answer== data1[currentQuiz].correct){
        score++
        wronganswer=total-score; 
        percentage=score*100/total
        
    }
    currentQuiz++
    if(currentQuiz < data1.length){
        loadQuiz()
      
       
    }

    
    else
   
       
     quiz.innerHTML =`
     <h2>your score is${score}</h2>
     
     <h2>Total question=10</h2>
     <h2>currect answer: ${score}</h2>
     <h2>wrong answer: ${wronganswer}</h2>
     <h2>wrong answer: ${percentage} %</h2>
     <h2>you answered: ${score}/${data1.length} Questions correctly</h2>
     <button onclick= "location.reload()">Do it Again</button>
     

    `
}
   

})

